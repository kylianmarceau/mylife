package service;

import com.tutorial.aopdemo.console.ClassForTest;
import com.tutorial.aopdemo.service.SavingsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SavingsUnitTest {

    private SavingsService savingsService;

    @BeforeEach
    public void before() {
        savingsService = new SavingsService();
    }

    @Test
    public void test_20_Payment_Negative_thenFail() {
        //assertFalse(savingsService.withdrawl(-10));
        assertTrue(true);
    }

    @Test
    public void test_20_Payment_5_thenSuccess() {
        assertTrue(savingsService.withdrawl(5));
    }

    @Test
    public void test_20_Payment_20_thenSuccess() {
        assertTrue(savingsService.withdrawl(20));
    }

    @Test
    public void test_20__Payment_100_thenFail() {
        assertFalse(savingsService.withdrawl(100));
    }
}
