package com.tutorial.aopdemo.service;

public class SavingsService {
    int savingsAmount = 20;

    public boolean withdrawl(int amount) {
        if (savingsAmount < amount) {
            return false;
        } else if (amount < 0) {
            throw new IllegalArgumentException("The amount cannot be negative.");
        } else {
            savingsAmount = savingsAmount - amount;
            return true;
        }
    }

    public int getSavingsAmount() {
        return savingsAmount;
    }

    public void setSavingsAmount(int savingsAmount) {
        this.savingsAmount = savingsAmount;
    }
}
