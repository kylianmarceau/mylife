package com.tutorial.aopdemo.service;

public class AccountService {

    public void deposit(double amount) {
        System.out.println("Deposit amount: " + amount);
    }

    public void withdrawl(double amount) {
        System.out.println("Withdrawl amount: " + amount);
    }
}
