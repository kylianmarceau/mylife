package core.aspects;

import com.tutorial.aopdemo.service.SavingsService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class SavingsAspect {

    final int MIN_AMOUNT = 10;

    @Before("execution(* com.tutorial.aopdemo.service.SavingsService.withdrawl(int)) && args(amount)")
    public void beforeCalculation(JoinPoint joinPoint, int amount) {
        Object[] args = joinPoint.getArgs();
        SavingsService savingsService = (SavingsService) joinPoint.getTarget();
        System.out.println("Before withdrawl (" + amount + "€) : from account: " + savingsService.getSavingsAmount() + "€");
    }

    @After("execution(* com.tutorial.aopdemo.service.SavingsService.withdrawl(int)) && args(amount)")
    public void afterCalculation(JoinPoint joinPoint, int amount) {
        Object[] args = joinPoint.getArgs();
        SavingsService savingService = (SavingsService) joinPoint.getTarget();
        System.out.println("After withdrawl (" + amount + "€) :  from acoount: " + savingService.getSavingsAmount() + "€");
    }
}
