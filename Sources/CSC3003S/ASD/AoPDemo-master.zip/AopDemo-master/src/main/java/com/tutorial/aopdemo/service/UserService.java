package com.tutorial.aopdemo.service;

public class UserService {

    public void createUser(String username, String password) {
        System.out.println("Creating user: " + username);
    }

    public void updateUser(String username) {
        System.out.println("Updating user: " + username);
    }

    public void deleteUser(String username) {
        System.out.println("Deleting user: " + username);
    }
}
