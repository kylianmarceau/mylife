package core.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AuthorizationAspect {
    @Pointcut("execution(* com.tutorial.aopdemo.*.*(..))") // All Methods in unit com.example.jsf.controller.*
    private void controllerMethods() {}

    @Before("controllerMethods()")
    public void checkAuthorization() {
        // Here is the code that checks users
        System.out.println("Authorization checked.");
    }
}