package com.tutorial.aopdemo.console;


import com.tutorial.aopdemo.service.SavingsService;

public class Konto_Main {

    public static void main(String[] args) {
        SavingsService kontoService = new SavingsService();
        kontoService.withdrawl(5);
    }
}
