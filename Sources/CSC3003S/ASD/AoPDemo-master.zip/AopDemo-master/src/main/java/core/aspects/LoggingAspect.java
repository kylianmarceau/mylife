package core.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;

@Aspect
public class LoggingAspect {

    // ANSI escape code constants for text colors
    String RESET = "\u001B[0m";
    String RED = "\u001B[31m";
    String GREEN = "\u001B[32m";
    String YELLOW = "\u001B[33m";
    String BLUE = "\u001B[34m";
    String PURPLE = "\u001B[35m";
    String CYAN = "\u001B[36m";

    //  @Before("execution(* com.tutorial.aopdemo.*.*(..))")
    @Before("execution(* *(..))") // Matches every method in the project
    public void logBefore(JoinPoint joinPoint) {
        System.out.println(RED + "Method called: " + YELLOW + joinPoint.getSignature().getName() + RESET);
    }

    @AfterReturning(pointcut = "execution(* *(..))", returning = "result") // After successful completion of any method
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        System.out.println(BLUE + "Method completed successfully: " + YELLOW + joinPoint.getSignature().getName() + BLUE + " - return value: " + PURPLE + result);
        System.out.println(GREEN + "*************************************************************************" + RESET);
    }

    @AfterThrowing(pointcut = "execution(* com.tutorial.aopdemo.service.SavingsService.withdrawl(int))", throwing = "exception")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable exception) {
        System.out.println(RED + "Method throw an exception: " + YELLOW + joinPoint.getSignature().getName() + " - error: " + exception + RESET);
        System.out.println(RED + "Error: " + YELLOW + exception.getMessage() + CYAN + " Exception handled by aspect." + RESET);
        System.out.println(GREEN + "*************************************************************************" + RESET);
    }
}
